import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
    private static int[][] dir={{-1,0,1,0},{0,1,0,-1}};
    private int[][] blocks;
    private final WeightedQuickUnionUF dsu;
    private final int nN;
    private int numberOfOpen;    
    public Percolation(int n) {
        if (n<=0)
            throw new java.lang.IllegalArgumentException();
        nN=n;
        dsu = new WeightedQuickUnionUF(nN*nN+2);
        numberOfOpen=0;
        blocks = new int[n+1][n+1];
        for (int i=1; i<=n; ++i){
            for (int j=1; j<=n; ++j){
                blocks[i][j]=0;
            }
        }
        for (int i=1;i<=nN;++i) {
            dsu.union(0,i);
            dsu.union(nN*nN+1,(nN-1)*nN+i);
        }
    }
    public void open(int row, int col) {
        if (row<=0 || row>nN || col<=0 || col>nN)
            throw new java.lang.IllegalArgumentException();
        if (blocks[row][col]==0){
            blocks[row][col]=1;
            ++numberOfOpen;
            for (int i=0; i<4; ++i){
                int r=row+dir[0][i];
                int c=col+dir[1][i];
                if (r>=1 && r<=nN && c>=1 && c<=nN){
                    if (isOpen(r,c))
                        dsu.union((row-1)*nN+col,(r-1)*nN+c);
                }
            }
        }
    }
    public boolean isOpen(int row, int col){
        if (row<=0 || row>nN || col<=0 || col>nN)
            throw new java.lang.IllegalArgumentException();
        return blocks[row][col]==1;
    }
    public boolean isFull(int row, int col){
        if (row<=0 || row>nN || col<=0 || col>nN)
            throw new java.lang.IllegalArgumentException();
        if (!isOpen(row,col))
            return false;
        else
            return dsu.connected(0,(row-1)*nN+col);
    }
    public int numberOfOpenSites(){
        return numberOfOpen;
    }
    public boolean percolates(){
        return dsu.connected(0,nN*nN+1);
    }
    
    public static void main(String[] args){
        Percolation pr = new Percolation(3);
        pr.open(1,1);
        pr.open(3,1);
        pr.open(2,1);
        System.out.println(pr.percolates());
        System.out.println(pr.numberOfOpenSites());
    }
}