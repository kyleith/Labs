import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats {
    private final double [] x;
    private final int T;
    public PercolationStats(int n, int trials) {    // perform trials independent experiments on an n-by-n grid
        if (n<=0 || trials<=0)
            throw new java.lang.IllegalArgumentException();
        T=trials;
        x = new double[trials];
        for (int i=0;i<trials;++i) {
            Percolation perc = new Percolation(n);
            while (!perc.percolates()){
                int cell=StdRandom.uniform(n*n)+1;
                int r=(cell-1)/n+1;
                int c=cell%n;
                if (c==0) c=n;
                perc.open(r,c);
            }
            x[i]=(double)perc.numberOfOpenSites()/(double)(n*n);
        }
    }
    public double mean() {                         // sample mean of percolation threshold
        return StdStats.mean(x);
    }
    public double stddev() {                        // sample standard deviation of percolation threshold
        return StdStats.stddev(x);
    }
    public double confidenceLo() {                 // low  endpoint of 95% confidence interval
        return mean()-1.96*stddev()/Math.sqrt(T);
    }
    public double confidenceHi() {                // high endpoint of 95% confidence interval
        return mean()+1.96*stddev()/Math.sqrt(T);
    }

    public static void main(String[] args) {       
        int n=Integer.parseInt(args[0]);
        int t=Integer.parseInt(args[1]);
        PercolationStats ps = new PercolationStats(n,t);
        System.out.print("mean                    = ");
        System.out.println(ps.mean());
        System.out.printf("stddev                  = ");
        System.out.println(ps.stddev());
        System.out.print("95% confidence interval = [");
        System.out.print(ps.confidenceLo());
        System.out.print(", ");
        System.out.print(ps.confidenceHi());
        System.out.println("]");
    }
}